package encryptfiles;

import java.util.ArrayList;

public class App {

    public final static ArrayList<AES> cipherKeys = new ArrayList<>();

}
