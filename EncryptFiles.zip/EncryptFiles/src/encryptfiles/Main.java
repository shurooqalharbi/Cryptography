package encryptfiles;

import com.alee.laf.WebLookAndFeel;
import com.alee.skin.dark.WebDarkSkin;
import java.awt.HeadlessException;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Main extends javax.swing.JFrame {

    boolean keysOpened = false;

    public Main() {
        initComponents();
        jFileChooser1.setApproveButtonText("En/Decrypt");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFileChooser1 = new javax.swing.JFileChooser();
        jLabel1 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jFileChooser1.setDialogType(javax.swing.JFileChooser.CUSTOM_DIALOG);
        jFileChooser1.setFileSelectionMode(javax.swing.JFileChooser.FILES_AND_DIRECTORIES);
        jFileChooser1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFileChooser1ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel1.setText("Cryptofile");

        jLabel2.setText("Encryption Keys");

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/settings.png"))); // NOI18N
        jButton3.setMaximumSize(new java.awt.Dimension(80, 80));
        jButton3.setMinimumSize(new java.awt.Dimension(80, 80));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(293, 293, 293)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jFileChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 683, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addComponent(jLabel2)
                                .addGap(69, 69, 69)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(85, 85, 85)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(32, 32, 32)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jSeparator1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jFileChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(420, 420, 420)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (!keysOpened) {
            Keys keys = new Keys(this);

            keys.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    keysOpened = false;
                    super.windowClosing(e);
                }
            });

            keys.setVisible(true);
            keysOpened = true;
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jFileChooser1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFileChooser1ActionPerformed
        File selectedFile = jFileChooser1.getSelectedFile();
        int selectedIndex = jComboBox1.getSelectedIndex();
        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(this, "Choose Key to use.");
            return;
        }
        AES aes = App.cipherKeys.get(selectedIndex);

        if (selectedFile.getAbsolutePath().endsWith(".encrypted")) {
            if (selectedFile.getAbsolutePath().endsWith(".dir.encrypted")) {
                String output = Utils.stripExtension(
                        Utils.stripExtension(selectedFile.getPath()));
                decryptDirectory(selectedFile, output, aes);
            } else {
                String output = Utils.stripExtension(selectedFile.getPath());
                decrypt(selectedFile, output, aes);
            }
        } else {
            if (selectedFile.isDirectory()) {
                ecnryptDirectory(selectedFile, aes);
            } else {
                String outputFile = selectedFile.getAbsolutePath()
                        + ".encrypted";
                encrypt(selectedFile, outputFile, aes);
            }
        }

        File currentDirectory = jFileChooser1.getCurrentDirectory();
        jFileChooser1.setCurrentDirectory(new File("/"));
        jFileChooser1.setCurrentDirectory(currentDirectory);
    }//GEN-LAST:event_jFileChooser1ActionPerformed

    private void decryptDirectory(File selectedFile, String outPath, AES aes) {
        try {
            decrypt(selectedFile, outPath + ".dir", aes);
            Utils.zipDecompress(outPath + ".dir", outPath);
            Utils.deleteDir(new File(outPath + ".dir"));
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(rootPane, "Error in decompressing");
            ex.printStackTrace();
        }
    }

    private void ecnryptDirectory(File selectedFile, AES aes) {
        try {
            String outPath = selectedFile.getAbsolutePath();
            if (Utils.zipCompress(selectedFile, new File(outPath + ".dir"))) {
                encrypt(new File(outPath + ".dir"), outPath
                        + ".dir.encrypted", aes);
                Utils.deleteDir(new File(outPath + ".dir"));
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(rootPane, "Error in compressing");
            ex.printStackTrace();
        }
    }

    private void encrypt(File selectedFile, String outPath, AES aes)
            throws HeadlessException {
        try {
            DataInputStream dataInputStream = new DataInputStream(
                    new FileInputStream(selectedFile));

            try (DataOutputStream dataOutputStream = new DataOutputStream(
                    new FileOutputStream(outPath))) {
                includeSize(dataInputStream, dataOutputStream);
                includeHash(selectedFile, dataOutputStream);

                final int INPUT_BUFFER_SIZE = 16;
                byte[] dat;
                while (dataInputStream.available() > INPUT_BUFFER_SIZE) {
                    dat = new byte[INPUT_BUFFER_SIZE];
                    dataInputStream.read(dat);
                    dat = aes.encrypt(dat);
                    dataOutputStream.write(dat);
                }
                if (dataInputStream.available() > 0) {
                    int len = dataInputStream.available();
                    while ((len % INPUT_BUFFER_SIZE) != 0) {
                        len++;
                    }
                    dat = new byte[len];
                    dataInputStream.read(dat);
                    dat = aes.encrypt(dat);
                    dataOutputStream.write(dat);
                }
            }
            JOptionPane.showMessageDialog(rootPane,
                    "File Encrypted Successfully");
        } catch (IOException | NoSuchAlgorithmException
                | NoSuchPaddingException | InvalidKeyException
                | IllegalBlockSizeException | BadPaddingException ex) {
            JOptionPane.showMessageDialog(this, ex.getClass() + "\n"
                    + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void decrypt(File selectedFile, String outPath, AES aes)
            throws HeadlessException {
        try {
            DataInputStream dataInputStream = new DataInputStream(
                    new FileInputStream(selectedFile));

            int plainSize = exportSize(dataInputStream);
            byte[] hash = exportHash(dataInputStream);

            final int INPUT_BUFFER_SIZE = 16;
            final int OUTPUT_BUFFER_SIZE = INPUT_BUFFER_SIZE * 2;

            if (dataInputStream.available() % OUTPUT_BUFFER_SIZE != 0) {
                JOptionPane.showMessageDialog(this, "Sorry,Bad File.");
                return;
            }

            int realSize = dataInputStream.available();

            try (DataOutputStream dataOutputStream = new DataOutputStream(
                    new FileOutputStream(outPath))) {
                int lastSize = INPUT_BUFFER_SIZE - ((realSize / 2) - plainSize);

                byte[] dat;
                while (dataInputStream.available() > 0) {
                    dat = new byte[OUTPUT_BUFFER_SIZE];
                    dataInputStream.read(dat);
                    dat = aes.decrypt(dat);
                    if (dataInputStream.available() <= lastSize) {
                        byte[] last = new byte[lastSize];
                        System.arraycopy(dat, 0, last, 0, lastSize);
                        dataOutputStream.write(last);
                    } else {
                        dataOutputStream.write(dat);
                    }
                }
            }
            byte[] outhash = Utils.createSha1(new File(outPath));
            if (Arrays.equals(outhash, hash)) {
                JOptionPane.showMessageDialog(this, "* File Decrypted "
                        + "Successfully.\n * SHA-1 Successfully checked");
            } else {
                JOptionPane.showMessageDialog(this, "* File Decrypted "
                        + "Successfully.\n * SHA-1 is not valid !");
            }

        } catch (IOException | NoSuchAlgorithmException | NoSuchPaddingException
                | InvalidKeyException | IllegalBlockSizeException
                | BadPaddingException ex) {
            JOptionPane.showMessageDialog(this, ex.getClass() + "\n"
                    + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void includeHash(File selectedFile, DataOutputStream dataOutputStream)
            throws NoSuchAlgorithmException, IOException {
        byte[] hash = Utils.createSha1(selectedFile);
        dataOutputStream.write(hash);
    }

    private void includeSize(DataInputStream dataInputStream,
            DataOutputStream dataOutputStream) throws IOException {
        byte[] size = Utils.intToBytes(dataInputStream.available());
        dataOutputStream.write(size);
    }

    private byte[] exportHash(DataInputStream dataInputStream)
            throws IOException {
        byte[] hash = new byte[20];
        dataInputStream.read(hash);
        return hash;
    }

    private int exportSize(DataInputStream dataInputStream) throws IOException {
        byte[] firstBytes = new byte[8];
        dataInputStream.read(firstBytes);
        int plainSize = Utils.bytesToInt(firstBytes);
        return plainSize;
    }

    public static void main(String args[]) {

        SwingUtilities.invokeLater(() -> {
            WebLookAndFeel.install();
            // You can also specify preferred skin right-away
            WebLookAndFeel.install(WebDarkSkin.class);

        });
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Main().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton3;
    public javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
