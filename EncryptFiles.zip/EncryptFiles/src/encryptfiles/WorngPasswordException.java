package encryptfiles;

public class WorngPasswordException extends Exception {

    public WorngPasswordException(String string) {
        super(string);
    }

}
