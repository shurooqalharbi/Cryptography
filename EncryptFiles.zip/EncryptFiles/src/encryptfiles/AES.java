package encryptfiles;

import java.io.Serializable;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Date;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

/**
 * This class will be used to contain AES key information, it will contain key
 * name, key password, key date, and the key it self..
 */
public class AES implements Serializable {

    /**
     * the name of the key
     */
    public final String name;
    final SecretKeySpec secretKey;
    final String date;
    String password = null;

    /**
     * This is a contractor to the key class, so from here we can create a new
     * key.
     *
     * @param name the name of the key
     * @throws NoSuchAlgorithmException when the algorithm is unknown
     * @throws NoSuchPaddingException when it fail to know the padding type
     */
    public AES(String name) throws NoSuchAlgorithmException, NoSuchPaddingException {
        if (name == null) {
            name = "";
        }
        this.name = name;
        this.date = new Date().toString();

        byte[] bytes = new byte[16];
        new SecureRandom().nextBytes(bytes);
        MessageDigest sha = MessageDigest.getInstance("SHA-1");
        bytes = sha.digest(bytes);
        bytes = Arrays.copyOf(bytes, 16);
        this.secretKey = new SecretKeySpec(bytes, "AES");
    }

    /**
     * This is a contractor to the key class, so from here we can create a new
     * key.
     *
     * @param name the name of the key
     * @param password the password of the key
     * @throws NoSuchAlgorithmException when the algorithm is unknown
     * @throws NoSuchPaddingException when it fail to know the padding type
     * @throws WorngPasswordException when the password is not accepted
     */
    public AES(String name, String password) throws NoSuchAlgorithmException,
            NoSuchPaddingException, WorngPasswordException {
        if (name == null) {
            name = "";
        }
        if (password == null) {
            throw new WorngPasswordException("You can't make a null your password");
        }
        this.name = name;
        this.date = new Date().toString();

        byte[] bytes = new byte[16];
        new SecureRandom().nextBytes(bytes);
        MessageDigest sha = MessageDigest.getInstance("SHA-1");
        bytes = sha.digest(bytes);
        bytes = Arrays.copyOf(bytes, 16);
        this.secretKey = new SecretKeySpec(bytes, "AES");
        this.password = password;
    }

    /**
     * This method is used to encrypt array of bytes using the key
     *
     * @param plain the pain byes
     * @return array of encrypted bytes
     * @throws NoSuchAlgorithmException when there is no algorithm used
     * @throws NoSuchPaddingException when the padding used is unknown
     * @throws InvalidKeyException when the key used is invalid
     * @throws IllegalBlockSizeException when the block size is not accepted
     * @throws BadPaddingException when the padding used is not accepted
     */
    public byte[] encrypt(byte[] plain) throws NoSuchAlgorithmException,
            NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {

        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        return cipher.doFinal(plain);
    }

    /**
     * this method is used to decrypt the array of bytes using this key.
     *
     * @param ciphered the array of encrypted bytes to decrypt
     * @return the clear array of bytes after decrypting the ciphered
     * @throws NoSuchAlgorithmException when there is no algorithm used
     * @throws NoSuchPaddingException when the padding used is unknown
     * @throws InvalidKeyException when the key used is invalid
     * @throws IllegalBlockSizeException when the block size is not accepted
     * @throws BadPaddingException when the padding used is not accepted
     */
    public byte[] decrypt(byte[] ciphered) throws NoSuchAlgorithmException,
            NoSuchPaddingException, IllegalBlockSizeException, InvalidKeyException, BadPaddingException {
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        return cipher.doFinal(ciphered);
    }

    /**
     * this method is used when we want to print key.
     *
     * @return key name
     */
    @Override
    public String toString() {
        return name;
    }

    /**
     * this method is used to check if 2 keys are equal each other
     *
     * @param aes the key to compare with current
     * @return true when they are the same key, false otherwise
     */
    public boolean equals(AES aes) {
        return Arrays.equals(aes.secretKey.getEncoded(), this.secretKey.getEncoded())
                && aes.date.equals(this.date)
                && aes.name.equals(this.name)
                && aes.password.equals(this.password);
    }

}
