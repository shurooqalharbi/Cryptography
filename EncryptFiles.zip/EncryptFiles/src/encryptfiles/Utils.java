package encryptfiles;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class Utils {

    public static String stripExtension(String str) {
        if (str == null) {
            return null;
        }
        int pos = str.lastIndexOf(".");
        if (pos == -1) {
            return str;
        }
        return str.substring(0, pos);
    }

    public static byte[] intToBytes(int x) {
        ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES);
        buffer.putInt(x);
        return buffer.array();
    }

    public static int bytesToInt(byte[] bytes) {
        ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES);
        buffer.put(bytes);
        buffer.flip();//need flip 
        return buffer.getInt();
    }

    public static byte[] createSha1(File file) throws NoSuchAlgorithmException, FileNotFoundException, IOException {
        MessageDigest digest = MessageDigest.getInstance("SHA-1");
        InputStream fis = new FileInputStream(file);
        int n = 0;
        byte[] buffer = new byte[8192];
        while (n != -1) {
            n = fis.read(buffer);
            if (n > 0) {
                digest.update(buffer, 0, n);
            }
        }
        return digest.digest();
    }

    public static boolean zipCompress(File inputDir, File outputZipFile) throws IOException {
        // Create parent directory for the output file.
        outputZipFile.getParentFile().mkdirs();

        String inputDirPath = inputDir.getAbsolutePath();
        byte[] buffer = new byte[1024];

        List<File> allFiles = listChildFiles(inputDir);

        // Create ZipOutputStream object to write to the zip file
        try (ZipOutputStream zipOs = new ZipOutputStream(new FileOutputStream(outputZipFile))) {
            for (File file : allFiles) {
                String filePath = file.getAbsolutePath();

                System.out.println("Zipping " + filePath);

                // entryName
                String entryName = filePath.substring(inputDirPath.length() + 1);

                ZipEntry ze = new ZipEntry(entryName);
                // Put new entry into zip file.
                zipOs.putNextEntry(ze);
                // Read the file and write to ZipOutputStream
                try (FileInputStream fileIs = new FileInputStream(filePath)) {
                    int len;
                    while ((len = fileIs.read(buffer)) > 0) {
                        zipOs.write(buffer, 0, len);
                    }
                }
            }
        }
        return true;
    }

    public static boolean zipDecompress(String inputFile, String outputFolder) throws IOException {

        // Create Output folder if it does not exists.
        File folder = new File(outputFolder);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        // Create a buffer.
        byte[] buffer = new byte[1024];

        // Create ZipInputStream object to read a file from path.
        try (ZipInputStream zipIs = new ZipInputStream(new FileInputStream(inputFile))) {

            // Read ever Entry (From top to bottom until the end)
            ZipEntry entry;
            while ((entry = zipIs.getNextEntry()) != null) {
                String entryName = entry.getName();
                String outFileName = outputFolder + File.separator + entryName;
                System.out.println("Unzip: " + outFileName);

                if (entry.isDirectory()) {
                    // Make directories.
                    new File(outFileName).mkdirs();
                } else {
                    // Create Stream to write file.
                    try (FileOutputStream fos = new FileOutputStream(outFileName)) {
                        int len;
                        // Read the data on the current entry.
                        while ((len = zipIs.read(buffer)) > 0) {
                            fos.write(buffer, 0, len);
                        }
                    }
                }
            }
        }
        return true;
    }

    public static void deleteDir(File file) {
        File[] contents = file.listFiles();
        if (contents != null) {
            for (File f : contents) {
                if (!Files.isSymbolicLink(f.toPath())) {
                    deleteDir(f);
                }
            }
        }
        file.delete();
    }

    public static boolean move(File sourceFile, File destFile) {
        if (sourceFile.isDirectory()) {
            for (File file : sourceFile.listFiles()) {
                move(file, new File(file.getPath().substring("temp".length() + 1)));
            }
        } else {
            try {
                Files.move(Paths.get(sourceFile.getPath()), Paths.get(destFile.getPath()), StandardCopyOption.REPLACE_EXISTING);
                return true;
            } catch (IOException e) {
                return false;
            }
        }
        return false;
    }

    // This method returns the list of files,
    // including the children, grandchildren files of the input folder.
    private static List<File> listChildFiles(File dir) throws IOException {
        List<File> allFiles = new ArrayList();
        File[] childFiles = dir.listFiles();
        for (File file : childFiles) {
            if (file.isDirectory()) {
                List<File> files = listChildFiles(file);
                allFiles.addAll(files);
            } else {
                allFiles.add(file);
            }
        }
        return allFiles;
    }

}
